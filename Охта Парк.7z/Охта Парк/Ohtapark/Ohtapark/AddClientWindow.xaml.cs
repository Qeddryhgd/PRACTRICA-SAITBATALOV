﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Drawing;

namespace Ohtapark
{
    /// <summary>
    /// Логика взаимодействия для AddClientWindow.xaml
    /// </summary>
    public partial class AddClientWindow : Window
    {
        public AddClientWindow()
        {
            InitializeComponent();
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFIO.Text))
            {
                MessageBox.Show("ФИО обязательно!");
                return;
            }

            var client = new Entities.Client
            {
                FIO = txtFIO.Text,
                CodeClient = txtCodeClient.Text,
                DateOfBirth = dpDateOfBirth.SelectedDate,
                Address = txtAddress.Text,
                Email = txtEmail.Text,
                PassportSeries = txtPassportSeries.Text,
                PassportNumber = txtPassportNumber.Text,
                Password = "default123" // Можно сделать генерацию
            };

            App.ohtaEntities.Clients.Add(client);
            App.ohtaEntities.SaveChanges();

            MessageBox.Show("Клиент успешно добавлен!");
            DialogResult = true;
            Close();
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            DialogResult = false;
            Close();
        }
    }
}