﻿using Ohtapark.Entities;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;

using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;

using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;


namespace Ohtapark
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private int loginAttempts = 0;
        private const int MAX_ATTEMPTS = 3;
        private DateTime? lockoutTime = null;
        private const int LOCKOUT_DURATION = 300; // 5 минут
        private DispatcherTimer timer;
        private string currentCaptcha = "";

        public MainWindow()
        {
            InitializeComponent();
            LoadCaptcha();
            StartTimer();
        }

        private void LoadCaptcha()
        {
            var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            var random = new Random();
            currentCaptcha = new string(Enumerable.Repeat(chars, 6)
                .Select(s => s[random.Next(s.Length)]).ToArray());
            lblCaptcha.Text = currentCaptcha;
        }

        private void RefreshCaptcha_Click(object sender, RoutedEventArgs e)
        {
            LoadCaptcha();
            txtCaptcha.Clear();
        }

        private void StartTimer()
        {
            timer = new DispatcherTimer();
            timer.Interval = TimeSpan.FromSeconds(1);
            timer.Tick += Timer_Tick;
            timer.Start();
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            lblTimer.Text = $"Текущее время: {DateTime.Now:HH:mm:ss}";
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            if (lockoutTime.HasValue && DateTime.Now.Subtract(lockoutTime.Value).TotalSeconds < LOCKOUT_DURATION)
            {
                MessageBox.Show($"Система заблокирована. Попробуйте через {LOCKOUT_DURATION - (int)DateTime.Now.Subtract(lockoutTime.Value).TotalSeconds} секунд");
                return;
            }

            if (txtCaptcha.Text != currentCaptcha)
            {
                MessageBox.Show("Неправильная капча!");
                LoadCaptcha();
                txtCaptcha.Clear();
                return;
            }

            var employee = App.ohtaEntities.Employees
                .FirstOrDefault(emp => emp.Login == txtLogin.Text && emp.Password == pwdPassword.Password);

            if (employee == null)
            {
                loginAttempts++;
                lblAttempts.Text = $"Неверный логин или пароль. Попыток осталось: {MAX_ATTEMPTS - loginAttempts}";

                if (loginAttempts >= MAX_ATTEMPTS)
                {
                    lockoutTime = DateTime.Now;
                    MessageBox.Show("Система заблокирована на 5 минут из-за превышения попыток входа.");
                }
                return;
            }

            // Успешный вход
            loginAttempts = 0;
            lblAttempts.Text = "";
            lockoutTime = null;

            // Обновляем последний вход
            employee.LastLogin = DateTime.Now;
            App.ohtaEntities.SaveChanges();

            // Открываем нужное окно по роли
            switch (employee.Position.Name)
            {
                case "Администратор":
                    new HistoryWindow().Show();
                    break;
                case "Старший смены":
                case "Продавец":
                    new OrderWindow().Show();
                    break;
                default:
                    MessageBox.Show("Неизвестная должность");
                    return;
            }

            this.Close(); // Закрываем окно входа
        }
    }
}