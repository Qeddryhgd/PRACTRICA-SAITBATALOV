﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data;
using System.Data.SqlClient;


namespace Ohtapark
{
    /// <summary>
    /// Логика взаимодействия для HistoryWindow.xaml
    /// </summary>
    public partial class HistoryWindow : Window
    {
        public HistoryWindow()
        {
            InitializeComponent();
            LoadOrders();
        }

        private void LoadOrders(string filter = "")
        {
            var query = from o in App.ohtaEntities.Orders
                        join c in App.ohtaEntities.Clients on o.ClientCode equals c.Code
                        join e in App.ohtaEntities.Employees on o.ID equals e.Code into empJoin
                        from e in empJoin.DefaultIfEmpty()
                        join s in App.ohtaEntities.Status on o.Status equals s.Code
                        select new
                        {
                            o.ID,
                            o.DateCreation,
                            o.TimeOrder,
                            Clients = c,
                            Statuses = s,
                            Employees = e
                        };

            if (!string.IsNullOrEmpty(filter))
            {
                query = query.Where(o => o.Employees != null && o.Employees.Login.Contains(filter));
            }

            dgOrders.ItemsSource = query.ToList();
        }

        private void txtFilterLogin_KeyUp(object sender, System.Windows.Input.KeyEventArgs e)
        {
            LoadOrders(txtFilterLogin.Text.Trim());
        }
    }
}