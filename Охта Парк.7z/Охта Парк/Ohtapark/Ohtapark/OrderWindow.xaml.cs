﻿using Ohtapark.Entities;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
    
namespace Ohtapark
{
    /// <summary>
    /// Логика взаимодействия для OrderWindow.xaml
    /// </summary>
    public partial class OrderWindow : Window
    {
        private List<int> selectedServiceIds = new List<int>();

        public OrderWindow()
        {
            InitializeComponent();
            LoadServices();
        }

        private void LoadServices()
        {
            dgServices.ItemsSource = App.ohtaEntities.Services.ToList();
        }

        private void AddClient_Click(object sender, RoutedEventArgs e)
        {
            var addClientWin = new AddClientWindow();
            if (addClientWin.ShowDialog() == true)
            {
                // Клиент успешно добавлен
                MessageBox.Show("Клиент добавлен!");
            }
        }

        private void SearchClient_Click(object sender, RoutedEventArgs e)
        {
            var searchWin = new Window
            {
                Title = "Поиск клиента",
                Width = 500,
                Height = 300
            };

            var stack = new StackPanel { Margin = new Thickness(10) }; // ✅ Правильно: Thickness

            var txtSearch = new TextBox();
            txtSearch.Text = ""; // Убираем PlaceholderText — его нет в WPF
            txtSearch.ToolTip = "Введите ФИО или код клиента"; // ✅ Альтернатива: подсказка при наведении

            var btnSearch = new Button { Content = "Найти", Width = 80 };
            var dgClients = new DataGrid { AutoGenerateColumns = false, Height = 200 };

            dgClients.Columns.Add(new DataGridTextColumn { Header = "Код", Binding = new System.Windows.Data.Binding("Code") });
            dgClients.Columns.Add(new DataGridTextColumn { Header = "ФИО", Binding = new System.Windows.Data.Binding("FIO") });
            dgClients.Columns.Add(new DataGridTextColumn { Header = "Email", Binding = new System.Windows.Data.Binding("Email") });

            btnSearch.Click += (s, ev) =>
            {
                var term = txtSearch.Text.Trim();
                var clients = App.ohtaEntities.Clients
                    .Where(c => c.FIO.Contains(term) || c.CodeClient.Contains(term))
                    .ToList();
                dgClients.ItemsSource = clients;
            };

            stack.Children.Add(txtSearch);
            stack.Children.Add(btnSearch);
            stack.Children.Add(dgClients);
            searchWin.Content = stack;
            searchWin.ShowDialog();
        }

        private void AddService_Click(object sender, RoutedEventArgs e)
        {
            if (dgServices.SelectedItem is Entities.Service selectedService)
            {
                if (!selectedServiceIds.Contains(selectedService.ID))
                {
                    selectedServiceIds.Add(selectedService.ID);
                    UpdateSelectedServicesLabel();
                }
            }
        }

        private void UpdateSelectedServicesLabel()
        {
            lblSelectedServices.Text = $"Выбрано услуг: {selectedServiceIds.Count}";
        }

        private void SaveOrder_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFIO.Text))
            {
                MessageBox.Show("Укажите ФИО клиента!");
                return;
            }

            // Найти или создать клиента
            var client = App.ohtaEntities.Clients.FirstOrDefault(c => c.FIO == txtFIO.Text);
            if (client == null)
            {
                client = new Entities.Client
                {
                    FIO = txtFIO.Text,
                    CodeClient = txtClientCode.Text,
                    DateOfBirth = dpDateOfBirth.SelectedDate,
                    Address = txtAddress.Text,
                    Email = txtEmail.Text,
                    PassportSeries = txtPassportSeries.Text,
                    PassportNumber = txtPassportNumber.Text
                };
                App.ohtaEntities.Clients.Add(client);
                App.ohtaEntities.SaveChanges();
            }

            // Создаем заказ
            var order = new Entities.Order
            {
                DateCreation = DateTime.Today,
                TimeOrder = DateTime.Now.ToString("HH:mm"),
                ClientCode = client.Code,
                Status = 1, // Пример: статус "в работе"
                RentalTime = 1 // По умолчанию 1 час
            };

            App.ohtaEntities.Orders.Add(order);
            App.ohtaEntities.SaveChanges();

            // Добавляем услуги
            foreach (var serviceId in selectedServiceIds)
            {
                var orderService = new Entities.OrderService
                {
                    OrderID = order.ID,
                    ServiceID = serviceId
                };
                App.ohtaEntities.OrderServices.Add(orderService);
            }

            App.ohtaEntities.SaveChanges();
            MessageBox.Show("Заказ успешно оформлен!");

            // Очистка формы
            ClearForm();
        }

        private void ClearForm()
        {
            txtClientCode.Clear();
            txtFIO.Clear();
            txtEmail.Clear();
            txtAddress.Clear();
            dpDateOfBirth.SelectedDate = null;
            txtPassportSeries.Clear();
            txtPassportNumber.Clear();
            txtPhone.Clear();
            selectedServiceIds.Clear();
            UpdateSelectedServicesLabel();
        }
    }
}