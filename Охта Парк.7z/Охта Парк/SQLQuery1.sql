use [is1-26-saitbatalovrg3]

-- Create Status table
CREATE TABLE Status (
    Code INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(50) NOT NULL
);

-- Create Positions table
CREATE TABLE Positions (
    Code INT PRIMARY KEY IDENTITY(1,1),
    Name NVARCHAR(50) NOT NULL
);

-- Create Clients table
CREATE TABLE Clients (
    Code INT PRIMARY KEY IDENTITY(1,1),
    FIO NVARCHAR(100) NOT NULL,
	CodeClient VARCHAR(100),
    DateOfBirth DATE,
    Address NVARCHAR(255),
    Email NVARCHAR(100),
	    Password NVARCHAR(100),
    PassportSeries NVARCHAR(4),
    PassportNumber NVARCHAR(6)

);

-- Create Services table
CREATE TABLE Services (
    ID INT PRIMARY KEY IDENTITY,
    Name NVARCHAR(100) NOT NULL,
    Code NVARCHAR(20) NOT NULL,
    CostPerHour DECIMAL(10,2) NOT NULL
);

-- Create Employees table
CREATE TABLE Employees (
    Code INT PRIMARY KEY IDENTITY(1,1),
    PositionCode INT NOT NULL,
    FIO NVARCHAR(100) NOT NULL,
    Login NVARCHAR(50) NOT NULL UNIQUE,
    Password NVARCHAR(100) NOT NULL,
    LastLogin DATE,
    LoginType NVARCHAR(20),
    FOREIGN KEY (PositionCode) REFERENCES Positions(Code) ON UPDATE CASCADE ON DELETE CASCADE
);

-- Create Orders table
CREATE TABLE Orders (
    ID INT PRIMARY KEY IDENTITY(1,1),
    DateCreation DATE NOT NULL,
    TimeOrder NVARCHAR(10) NOT NULL,
    ClientCode INT NOT NULL,
    Status INT NOT NULL,
    DateClosure DATE,
    RentalTime INT NOT NULL,
    FOREIGN KEY (ClientCode) REFERENCES Clients(Code) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (Status) REFERENCES Status(Code) ON UPDATE CASCADE ON DELETE CASCADE
);

-- Create OrderServices table
CREATE TABLE OrderServices (
ID INT PRIMARY KEY IDENTITY(1, 1),
    OrderID INT NOT NULL,
    ServiceID INT NOT NULL,
    FOREIGN KEY (OrderID) REFERENCES Orders(ID) ON UPDATE CASCADE ON DELETE CASCADE,
    FOREIGN KEY (ServiceID) REFERENCES Services(ID) ON UPDATE CASCADE ON DELETE CASCADE
);